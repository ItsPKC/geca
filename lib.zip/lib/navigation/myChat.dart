import 'package:flutter/material.dart';

class MyChat extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text('Chat Room');
  }
}
