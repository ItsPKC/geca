import 'package:flutter/material.dart';

class MyNotification extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text('Warnings'),
    );
  }
}
