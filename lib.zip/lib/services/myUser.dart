class MyUser {
  var uid;
  MyUser({this.uid});
}
